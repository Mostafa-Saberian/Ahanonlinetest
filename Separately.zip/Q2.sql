-- Question 2

select count (distinct Customer) as Number_of_Customers
from [dbo].[Sales]
