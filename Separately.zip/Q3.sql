-- Question 3

select Product, sum (Quantity) as TotalQuantity
from [dbo].[Sales]
group by Product
