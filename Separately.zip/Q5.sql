-- Question 5

with P as (select UnitPrice, Quantity, 
case when [dbo].[Profit].[ProfitRatio] is null then Quantity * UnitPrice * 0.1
else Quantity * UnitPrice * ProfitRatio end as Profit
from [dbo].[Sales] full join [dbo].[Profit] on Sales.Product = Profit.Product)

select sum (Profit) as TotalProfit, (sum (Profit)/ sum (Quantity*UnitPrice) *100) as TotalProfitPercentage
from P
