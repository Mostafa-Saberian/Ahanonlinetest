-- Question 4

select Customer, sum (UnitPrice*Quantity) as TotalBuy, count (distinct orderid) as Number_of_Orders, sum (Quantity) as TotalQuantity
from [dbo].[Sales]
where Customer in
(select Customer from [dbo].[Sales]
group by Customer, OrderID
having sum (UnitPrice*Quantity) > 1500)
group by Customer
