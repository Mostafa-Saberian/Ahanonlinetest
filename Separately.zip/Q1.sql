-- Question 1

select sum (Quantity*UnitPrice) as TotalSales
from [dbo].[Sales]
